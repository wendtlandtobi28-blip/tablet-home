# Tablet Home

Ein eigener Startbildschirm für das Samsung Tab A9. Die Oberfläche ist vom TV Home für den Fire TV Stick übernommen: große Uhr in der Mitte, Infos oben rechts und unten eine Leiste mit Apps und „Alle Apps“. Dazu kommen Wischgesten wie bei Apple. Die Einstellungen von Samsung, die Uhr und alle Apps bleiben nutzbar.

## Bedienung

- **Startseite:** große Uhr in der Mitte, Infos oben rechts (Wetter in Volksdorf, WLAN, Bluetooth, Datum), unten die Startreihe mit bis zu 6 Apps und „Alle Apps“. Vorgabe für die Startreihe sind Netflix, Prime Video, Joyn und YouTube, sofern installiert.
- **Von oben nach unten wischen**, direkt unter der Statusleiste:
  - links: Mitteilungen
  - rechts: Schnelleinstellungen (Flugmodus, WLAN, Bluetooth, Taschenlampe, Helligkeit, Lautstärke)
- **Nach oben wischen:** „Alle Apps“ mit Suchfeld. Lange auf eine App drücken: in die Startreihe aufnehmen, App-Info öffnen oder deinstallieren.
- **Lange auf eine freie Stelle drücken:** Menü mit Widgets, Alle Apps, Hintergrund und Uhr sowie Standard-Startapp.
- **Nach links wischen:** Widget-Seite, zum Beispiel mit der Uhr von Samsung. Zurück geht es mit Wischen nach rechts oder mit der Home-Taste.
- **Einstellungen:** Uhr (6 Stile), Hintergrund (Vorgaben oder ein eigenes Bild über eine Internet-Adresse), Infos oben rechts, Startreihe, Ruhemodus und Software-Update.

## Einrichten

1. Auf GitHub ein öffentliches Repo `tablet-home` anlegen. Der Name muss zu `GITHUB_REPO` in `Extras.kt` passen.
2. Die Datei `TabletHome_v1.zip` in die oberste Ebene des Repos hochladen.
3. Die Datei `build.yml` als `.github/workflows/build.yml` hochladen. Dafür den Ordner `.github/workflows` anlegen.
4. Im Reiter „Actions“ läuft der Build. Danach liegt die APK im Release „latest“.
5. Auf dem Tablet die APK aus dem Release herunterladen und öffnen. Beim ersten Mal die Installation für diese Quelle erlauben.
6. In den Einstellungen des Launchers „Startapp festlegen“ antippen und Tablet Home wählen. Samsung lässt sich über dieselbe Auswahl wieder einstellen.
7. Beim ersten Start fragt die App nach Standort (für den WLAN-Namen) und Bluetooth. Für die Mitteilungen „Mitteilungs-Zugriff öffnen“ antippen und dort Tablet Home erlauben. Für die Helligkeit „Helligkeit steuern erlauben“ antippen.

Wer den Code ändert, erstellt das ZIP neu und ersetzt es im Repo. Der Build startet dann von selbst.

## Eigenes Update

Der Launcher prüft beim Start und danach alle 6 Stunden das Release „latest“ auf GitHub. Liegt dort eine neuere APK, erscheint oben links „Update verfügbar“. Unter „Einstellungen → Software-Update“ lässt sich das Update installieren. Die Installation läuft über den Android-Installer und braucht eine Bestätigung am Tablet. Samsung ist dafür nicht nötig. Der Signierschlüssel bleibt gleich, deshalb bleiben Uhr, Widgets, Hintergrund und Startreihe erhalten.

## Grenzen

- Die Statusleiste oben und das Samsung-Schnellmenü bleiben von Samsung. Wer aus der Statusleiste wischt, öffnet weiterhin das Samsung-Menü.
- Der Flugmodus-Schalter öffnet die Einstellungen, weil Android Apps das Umschalten nicht erlaubt.
- Keine Ordner und kein Verschieben per Drag-and-drop. Die Apps in „Alle Apps“ sind alphabetisch sortiert.
- Die Uhr wandert nicht.
- Auf dem Gerät noch nicht getestet. Build-Fehler stehen im Reiter „Actions“.
