plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.tablethome"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.tablethome"
        minSdk = 28
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }

    // Fester Schlüssel (dieselbe Datei wie beim TV Home): Updates lassen sich drüber installieren
    signingConfigs {
        create("tobi") {
            storeFile = file("tvhome.keystore")
            storePassword = "tvhome123"
            keyAlias = "tobi"
            keyPassword = "tvhome123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("tobi")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("tobi")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
}
