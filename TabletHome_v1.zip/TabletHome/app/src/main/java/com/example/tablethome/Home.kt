@file:OptIn(ExperimentalFoundationApi::class)

package com.example.tablethome

import android.appwidget.AppWidgetHost
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDateTime

/**
 * Startbildschirm. Seite 1: Uhr und Infos (wie beim TV Home). Seite 2: Widgets.
 * Die Leiste unten bleibt auf beiden Seiten stehen.
 */
@Composable
fun HomeScreen(
    pagerState: PagerState,
    interactive: Boolean,
    nowState: State<LocalDateTime>,
    clockStyle: String,
    widgets: List<String>,
    statusState: State<DeviceStatus>,
    weatherState: State<Weather?>,
    dock: List<AppEntry>,
    loaded: Boolean,
    topInset: Dp,
    bottomInset: Dp,
    host: AppWidgetHost,
    prefs: Prefs,
    onLaunch: (AppEntry) -> Unit,
    onAllApps: () -> Unit,
    onNotif: () -> Unit,
    onQuick: () -> Unit,
    onMenu: () -> Unit,
    onUpdate: () -> Unit,
) {
    val density = LocalDensity.current
    val swipePx = with(density) { 60.dp.toPx() }
    val screenWidthDp = LocalConfiguration.current.screenWidthDp
    val screenWidthPx = with(density) { screenWidthDp.dp.toPx() }
    val notifCb by rememberUpdatedState(onNotif)
    val quickCb by rememberUpdatedState(onQuick)

    Box(Modifier.fillMaxSize()) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            userScrollEnabled = interactive,
        ) { page ->
            if (page == 0) {
                HomePage(
                    nowState = nowState,
                    clockStyle = clockStyle,
                    widgets = widgets,
                    statusState = statusState,
                    weatherState = weatherState,
                    topPad = topInset + 48.dp,
                    interactive = interactive,
                    onAllApps = onAllApps,
                    onMenu = onMenu,
                    onUpdate = onUpdate,
                )
            } else {
                WidgetPage(
                    host = host,
                    prefs = prefs,
                    topPad = topInset + 48.dp,
                    bottomPad = bottomInset + 200.dp,
                )
            }
        }

        // Obere Wischzone direkt unter der Statusleiste.
        // Nach unten wischen öffnet links die Mitteilungen, rechts die Schnelleinstellungen.
        if (interactive) {
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(top = topInset)
                    .height(40.dp)
                    .pointerInput(Unit) {
                        var startX = 0f
                        var sum = 0f
                        var fired = false
                        detectVerticalDragGestures(
                            onDragStart = { offset ->
                                startX = offset.x
                                sum = 0f
                                fired = false
                            },
                            onVerticalDrag = { _, dragAmount ->
                                sum += dragAmount
                                if (!fired && sum > swipePx) {
                                    fired = true
                                    if (startX < screenWidthPx / 2f) notifCb() else quickCb()
                                }
                            },
                        )
                    },
            )
        }

        if (loaded) {
            Dock(
                apps = dock,
                onLaunch = onLaunch,
                onAllApps = onAllApps,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = bottomInset),
            )
        }

        PageDots(
            current = pagerState.currentPage,
            count = 2,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = bottomInset + 176.dp),
        )
    }
}

/** Seite 1: große Uhr in der Mitte, Infos rechts oben, Hinweis links oben bei einem Update */
@Composable
private fun HomePage(
    nowState: State<LocalDateTime>,
    clockStyle: String,
    widgets: List<String>,
    statusState: State<DeviceStatus>,
    weatherState: State<Weather?>,
    topPad: Dp,
    interactive: Boolean,
    onAllApps: () -> Unit,
    onMenu: () -> Unit,
    onUpdate: () -> Unit,
) {
    val density = LocalDensity.current
    val swipePx = with(density) { 120.dp.toPx() }
    val allAppsCb by rememberUpdatedState(onAllApps)
    val menuCb by rememberUpdatedState(onMenu)

    val gestures: Modifier = if (interactive) {
        Modifier
            // Lange auf eine freie Stelle drücken: Menü
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { menuCb() })
            }
            // Nach oben wischen: Alle Apps (wie auf dem Samsung-Startbildschirm)
            .pointerInput(Unit) {
                var sum = 0f
                var fired = false
                detectVerticalDragGestures(
                    onDragStart = {
                        sum = 0f
                        fired = false
                    },
                    onVerticalDrag = { _, dragAmount ->
                        sum += dragAmount
                        if (!fired && sum < -swipePx) {
                            fired = true
                            allAppsCb()
                        }
                    },
                )
            }
    } else {
        Modifier
    }

    Box(Modifier.fillMaxSize().then(gestures)) {
        LiveClock(
            nowState = nowState,
            style = clockStyle,
            modifier = Modifier.align(Alignment.Center).offset(y = (-40).dp),
        )

        // Infos rechts oben, von oben nach unten (wie beim TV Home)
        if (widgets.isNotEmpty()) {
            InfoPanel(
                widgets = widgets,
                statusState = statusState,
                weatherState = weatherState,
                nowState = nowState,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = topPad, end = 44.dp)
                    .fillMaxHeight((0.15f * widgets.size).coerceAtMost(0.5f)),
            )
        }

        // Hinweis oben links, nur wenn wirklich ein Update bereitliegt
        if (UpdateState.available) {
            ChipButton(
                text = "Update verfügbar",
                onClick = onUpdate,
                modifier = Modifier.align(Alignment.TopStart).padding(top = topPad, start = 44.dp),
            )
        }
    }
}

/** Die Leiste unten: die Startreihe und "Alle Apps", wie beim TV Home */
@Composable
private fun Dock(
    apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onAllApps: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 28.dp)
            .clip(RoundedCornerShape(40.dp))
            .background(Brush.verticalGradient(listOf(Color(0x59FFFFFF), Color(0x33FFFFFF))))
            .border(1.dp, Color(0x59FFFFFF), RoundedCornerShape(40.dp))
            .padding(horizontal = 34.dp, vertical = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        apps.forEach { app ->
            NameTile(name = app.label, onClick = { onLaunch(app) }, modifier = Modifier.weight(1f))
        }
        // Fehlende Plätze freilassen, damit "Alle Apps" immer gleich breit bleibt
        repeat((PINNED_KEYS.size - apps.size).coerceAtLeast(0)) {
            Spacer(Modifier.weight(1f))
        }
        NameTile(name = "Alle Apps", onClick = onAllApps, modifier = Modifier.weight(1f))
    }
}

/** Seitenpunkte über der Leiste */
@Composable
private fun PageDots(current: Int, count: Int, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(count) { index ->
            val active = index == current
            Box(
                Modifier
                    .size(if (active) 9.dp else 7.dp)
                    .clip(CircleShape)
                    .background(if (active) LocalFg.current else LocalFg.current.copy(alpha = 0.5f))
            )
        }
    }
}

/** Menü bei langem Drücken auf eine freie Stelle des Startbildschirms */
@Composable
fun HomeMenu(
    onWidgets: () -> Unit,
    onAllApps: () -> Unit,
    onSettings: () -> Unit,
    onHomeApp: () -> Unit,
) {
    Column(
        modifier = Modifier
            .width(380.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Color(0xE61C1C1E))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        MenuItem(text = "Widgets", onClick = onWidgets)
        MenuItem(text = "Alle Apps", onClick = onAllApps)
        MenuItem(text = "Hintergrund und Uhr", onClick = onSettings)
        MenuItem(text = "Standard-Startapp wählen", onClick = onHomeApp)
    }
}

@Composable
private fun MenuItem(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x33FFFFFF))
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        Text(text = text, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Medium)
    }
}
