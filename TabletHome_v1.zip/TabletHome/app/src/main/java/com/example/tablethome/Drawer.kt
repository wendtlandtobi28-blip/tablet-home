@file:OptIn(ExperimentalFoundationApi::class)

package com.example.tablethome

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/** Symbole werden nur einmal geladen und danach wiederverwendet */
private val iconCache = ConcurrentHashMap<String, ImageBitmap>()

private fun loadIcon(pm: PackageManager, pkg: String): ImageBitmap? = runCatching {
    pm.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
}.getOrNull()

/** Das Symbol einer App, im Hintergrund geladen */
@Composable
fun AppIcon(packageName: String, iconSize: Dp, modifier: Modifier = Modifier) {
    val pm = LocalContext.current.packageManager
    val bitmap by produceState<ImageBitmap?>(initialValue = iconCache[packageName], key1 = packageName) {
        val cached = iconCache[packageName]
        if (cached != null) {
            value = cached
        } else {
            val loaded = withContext(Dispatchers.IO) { loadIcon(pm, packageName) }
            if (loaded != null) iconCache[packageName] = loaded
            value = loaded
        }
    }
    val icon = bitmap
    if (icon != null) {
        Image(
            bitmap = icon,
            contentDescription = null,
            modifier = modifier.size(iconSize).clip(RoundedCornerShape(14.dp)),
        )
    } else {
        Box(modifier = modifier.size(iconSize).clip(RoundedCornerShape(14.dp)).background(Color(0x33FFFFFF)))
    }
}

/**
 * Alle Apps: Suchfeld und das Raster aller Apps.
 * Lange auf eine App drücken öffnet ihr Menü (Startreihe, App-Info, Deinstallieren).
 */
@Composable
fun AllAppsOverlay(
    apps: List<AppEntry>,
    dock: List<String>,
    topInset: Dp,
    bottomInset: Dp,
    onLaunch: (AppEntry) -> Unit,
    onSettings: () -> Unit,
    onClose: () -> Unit,
    onDockChange: (List<String>) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    var menuFor by remember { mutableStateOf<AppEntry?>(null) }
    val shown = remember(apps, query) {
        val q = query.trim()
        if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            .padding(start = 32.dp, end = 32.dp, top = topInset + 16.dp, bottom = bottomInset + 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SearchField(value = query, onValueChange = { query = it }, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(16.dp))
            ChipButton(text = "Schließen", onClick = onClose)
        }
        Spacer(Modifier.height(20.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 150.dp),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (query.isBlank()) {
                item(key = "einstellungen") {
                    AppTile(
                        label = "Einstellungen",
                        packageName = null,
                        highlight = true,
                        onClick = onSettings,
                        onLongClick = null,
                    )
                }
            }
            items(shown, key = { it.packageName }) { app ->
                AppTile(
                    label = app.label,
                    packageName = app.packageName,
                    highlight = false,
                    onClick = { onLaunch(app) },
                    onLongClick = { menuFor = app },
                )
            }
        }
    }

    menuFor?.let { app ->
        AppMenuDialog(
            app = app,
            dock = dock,
            onDismiss = { menuFor = null },
            onDockChange = onDockChange,
        )
    }
}

@Composable
private fun AppTile(
    label: String,
    packageName: String?,
    highlight: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)?,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(if (highlight) Color(0x66FFFFFF) else Color(0x40000000))
            .combinedClickable(onLongClick = onLongClick, onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (packageName != null) {
            AppIcon(packageName = packageName, iconSize = 56.dp)
        } else {
            Box(Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(Color(0x66FFFFFF)))
        }
        Spacer(Modifier.height(10.dp))
        Text(
            text = label,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun AppMenuDialog(
    app: AppEntry,
    dock: List<String>,
    onDismiss: () -> Unit,
    onDockChange: (List<String>) -> Unit,
) {
    val context = LocalContext.current
    val inDock = app.packageName in dock
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1C1C1E),
        title = { Text(text = app.label, color = Color.White, fontWeight = FontWeight.SemiBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                MenuLine(text = if (inDock) "Aus Startreihe entfernen" else "In Startreihe aufnehmen") {
                    onDismiss()
                    when {
                        inDock -> onDockChange(dock - app.packageName)
                        dock.size >= MAX_DOCK -> Toast.makeText(
                            context,
                            "Die Startreihe ist voll (höchstens $MAX_DOCK Apps)",
                            Toast.LENGTH_LONG,
                        ).show()
                        else -> onDockChange(dock + app.packageName)
                    }
                }
                MenuLine(text = "App-Info") {
                    onDismiss()
                    runCatching {
                        context.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
                MenuLine(text = "Deinstallieren") {
                    onDismiss()
                    runCatching {
                        context.startActivity(
                            Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Schließen", color = Color.White)
            }
        },
    )
}

@Composable
private fun MenuLine(text: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Text(text = text, color = Color.White, fontSize = 17.sp)
    }
}

@Composable
private fun SearchField(value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x33FFFFFF))
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        if (value.isEmpty()) {
            Text(text = "Suchen", color = Color(0x99FFFFFF), fontSize = 20.sp)
        }
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 20.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}
