package com.example.tablethome

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.runtime.mutableStateListOf

/** Eine Mitteilung, so wie das Mitteilungs-Fenster sie zeigt */
data class NotifItem(
    val key: String,
    val appName: String,
    val title: String,
    val text: String,
    val time: Long,
    val intent: PendingIntent?,
)

/** Gemeinsame Liste aller Mitteilungen. Der Dienst füllt sie, das Fenster zeigt sie. */
object NotificationFeed {
    val items = mutableStateListOf<NotifItem>()

    fun add(context: Context, sbn: StatusBarNotification) {
        // Eigene Mitteilungen und laufende Meldungen (Musik, Download) auslassen
        if (sbn.packageName == context.packageName || sbn.isOngoing) return
        val extras = sbn.notification.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val appName = runCatching {
            val pm = context.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        }.getOrDefault(sbn.packageName)
        items.removeAll { it.key == sbn.key }
        items.add(0, NotifItem(sbn.key, appName, title, text, sbn.postTime, sbn.notification.contentIntent))
        while (items.size > 60) items.removeAt(items.lastIndex)
    }

    fun remove(key: String) {
        items.removeAll { it.key == key }
    }

    fun clear() {
        items.clear()
    }
}

/** Liest die Mitteilungen des Systems. Der Zugriff wird einmal in den Einstellungen erlaubt. */
class LauncherNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        instance = this
        NotificationFeed.clear()
        runCatching {
            activeNotifications?.forEach { NotificationFeed.add(this, it) }
        }
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        NotificationFeed.add(this, sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        NotificationFeed.remove(sbn.key)
    }

    companion object {
        /** Der laufende Dienst, damit Mitteilungen angetippt oder gelöscht werden können */
        @Volatile
        var instance: LauncherNotificationListener? = null
    }
}

/** Öffnet die Seite, auf der der Zugriff auf Mitteilungen erlaubt wird */
fun openListenerSettings(context: Context) {
    runCatching {
        context.startActivity(
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
