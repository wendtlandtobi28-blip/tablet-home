@file:Suppress("DEPRECATION")

package com.example.tablethome

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

/** Mitteilungen oben links. Antippen öffnet die App, das × entfernt die Mitteilung. */
@Composable
fun NotificationPanel(onClose: () -> Unit, resumeTick: Int, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val enabled = remember(resumeTick) {
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
    }
    val list = NotificationFeed.items

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(28.dp))
            .background(Color(0xE61C1C1E))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // Kopfzeile: nach oben wischen schließt das Fenster
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .pointerInput(Unit) {
                    var sum = 0f
                    detectVerticalDragGestures(
                        onDragStart = { sum = 0f },
                        onVerticalDrag = { _, dragAmount ->
                            sum += dragAmount
                            if (sum < -80f) onClose()
                        },
                    )
                },
        ) {
            Text(
                text = "Mitteilungen",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            if (enabled && list.isNotEmpty()) {
                ChipButton(
                    text = "Alle löschen",
                    onClick = {
                        LauncherNotificationListener.instance?.cancelAllNotifications()
                        NotificationFeed.clear()
                    },
                )
            }
        }

        when {
            !enabled -> {
                Text(
                    text = "Damit Tablet Home deine Mitteilungen zeigen kann, erlaube den Zugriff.",
                    color = Color(0xD9FFFFFF),
                    fontSize = 16.sp,
                )
                ChipButton(text = "Zugriff erlauben", onClick = { openListenerSettings(context) })
            }
            list.isEmpty() -> {
                Text(text = "Keine Mitteilungen", color = Color(0x99FFFFFF), fontSize = 16.sp)
            }
            else -> {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(list, key = { it.key }) { item ->
                        NotificationRow(
                            item = item,
                            onOpen = {
                                runCatching { item.intent?.send() }
                                LauncherNotificationListener.instance?.cancelNotification(item.key)
                                NotificationFeed.remove(item.key)
                            },
                            onDismiss = {
                                LauncherNotificationListener.instance?.cancelNotification(item.key)
                                NotificationFeed.remove(item.key)
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationRow(item: NotifItem, onOpen: () -> Unit, onDismiss: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x33FFFFFF))
            .clickable(onClick = onOpen)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = item.appName,
                color = Color(0xB3FFFFFF),
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Text(
                text = DateFormat.format("HH:mm", item.time).toString(),
                color = Color(0xB3FFFFFF),
                fontSize = 13.sp,
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = "×",
                color = Color.White,
                fontSize = 20.sp,
                modifier = Modifier.clickable(onClick = onDismiss).padding(horizontal = 4.dp),
            )
        }
        Text(
            text = item.title.ifBlank { item.appName },
            color = Color.White,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (item.text.isNotBlank()) {
            Text(
                text = item.text,
                color = Color(0xD9FFFFFF),
                fontSize = 15.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** Schnelleinstellungen oben rechts. Nach oben wischen oder daneben tippen schließt sie. */
@Composable
fun QuickPanel(onClose: () -> Unit, resumeTick: Int, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val camera = remember { context.getSystemService(Context.CAMERA_SERVICE) as CameraManager }
    val torchId = remember { torchCameraId(context) }
    val airplane = remember(resumeTick) { readAirplaneOn(context) }
    val wifi = remember(resumeTick) { readWifiOn(context) }
    val bluetooth = remember(resumeTick) { readBluetoothOn() }
    var torchOn by remember { mutableStateOf(false) }

    // Beim Schließen die Helligkeits-Automatik wieder so setzen, wie sie vorher war
    DisposableEffect(Unit) {
        val originalMode = readBrightnessMode(context)
        onDispose {
            if (Settings.System.canWrite(context)) {
                runCatching {
                    Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, originalMode)
                }
            }
        }
    }

    // Die Taschenlampe merkt sich, wenn andere Apps sie ein- oder ausschalten
    DisposableEffect(torchId) {
        val id = torchId
        if (id == null) {
            onDispose { }
        } else {
            val callback = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == id) torchOn = enabled
                }

                override fun onTorchModeUnavailable(cameraId: String) {
                    if (cameraId == id) torchOn = false
                }
            }
            runCatching { camera.registerTorchCallback(ContextCompat.getMainExecutor(context), callback) }
            onDispose { runCatching { camera.unregisterTorchCallback(callback) } }
        }
    }

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(28.dp))
            .background(Color(0xE61C1C1E))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Kopfzeile: nach oben wischen schließt das Fenster
        Text(
            text = "Schnelleinstellungen",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .fillMaxWidth()
                .pointerInput(Unit) {
                    var sum = 0f
                    detectVerticalDragGestures(
                        onDragStart = { sum = 0f },
                        onVerticalDrag = { _, dragAmount ->
                            sum += dragAmount
                            if (sum < -80f) onClose()
                        },
                    )
                },
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickTile(
                title = "Flugmodus",
                subtitle = if (airplane) "An" else "Aus",
                active = airplane,
                modifier = Modifier.weight(1f),
                onClick = { openSettingsPage(context, Settings.ACTION_AIRPLANE_MODE_SETTINGS) },
            )
            QuickTile(
                title = "WLAN",
                subtitle = if (wifi) "An" else "Aus",
                active = wifi,
                modifier = Modifier.weight(1f),
                onClick = { openWifiPanel(context) },
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickTile(
                title = "Bluetooth",
                subtitle = if (bluetooth) "An" else "Aus",
                active = bluetooth,
                modifier = Modifier.weight(1f),
                onClick = { openSettingsPage(context, Settings.ACTION_BLUETOOTH_SETTINGS) },
            )
            if (torchId != null) {
                QuickTile(
                    title = "Taschenlampe",
                    subtitle = if (torchOn) "An" else "Aus",
                    active = torchOn,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        val next = !torchOn
                        runCatching { camera.setTorchMode(torchId, next) }
                        torchOn = next
                    },
                )
            } else {
                Spacer(Modifier.weight(1f))
            }
        }

        Text(text = "Helligkeit", color = Color(0xB3FFFFFF), fontSize = 15.sp)
        if (Settings.System.canWrite(context)) {
            var brightness by remember { mutableStateOf(readBrightness(context)) }
            Slider(
                value = brightness,
                onValueChange = {
                    brightness = it
                    setBrightness(context, it.roundToInt())
                },
                valueRange = 1f..255f,
                colors = sliderColors(),
            )
        } else {
            ChipButton(text = "Helligkeit steuern erlauben", onClick = { openWriteSettings(context) })
        }

        Text(text = "Lautstärke", color = Color(0xB3FFFFFF), fontSize = 15.sp)
        val maxVolume = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat().coerceAtLeast(1f)
        var volume by remember { mutableStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
        Slider(
            value = volume.coerceIn(0f, maxVolume),
            onValueChange = {
                volume = it
                runCatching { audio.setStreamVolume(AudioManager.STREAM_MUSIC, it.roundToInt(), 0) }
            },
            valueRange = 0f..maxVolume,
            colors = sliderColors(),
        )
    }
}

@Composable
private fun QuickTile(
    title: String,
    subtitle: String,
    active: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Column(
        modifier = modifier
            .height(96.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(if (active) Color(0xF2FFFFFF) else Color(0x33FFFFFF))
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = title,
            color = if (active) Color(0xFF1C1C1E) else Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = subtitle,
            color = if (active) Color(0xB31C1C1E) else Color(0xB3FFFFFF),
            fontSize = 15.sp,
        )
    }
}

@Composable
private fun sliderColors() = SliderDefaults.colors(
    thumbColor = Color.White,
    activeTrackColor = Color.White,
    inactiveTrackColor = Color(0x40FFFFFF),
)

private fun readAirplaneOn(context: Context): Boolean =
    runCatching { Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 }
        .getOrDefault(false)

private fun readWifiOn(context: Context): Boolean =
    runCatching {
        (context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    }.getOrDefault(false)

private fun readBluetoothOn(): Boolean =
    runCatching { android.bluetooth.BluetoothAdapter.getDefaultAdapter()?.isEnabled == true }
        .getOrDefault(false)

private fun readBrightness(context: Context): Float =
    runCatching { Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS).toFloat() }
        .getOrDefault(128f)
        .coerceIn(1f, 255f)

private fun readBrightnessMode(context: Context): Int =
    runCatching { Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE) }
        .getOrDefault(Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)

/** Helligkeit von Hand: schaltet die Automatik aus, solange das Fenster offen ist */
private fun setBrightness(context: Context, value: Int) {
    runCatching {
        val resolver = context.contentResolver
        Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, value.coerceIn(1, 255))
    }
}

/** Die erste Kamera mit Blitz (zum Leuchten braucht die App keine Kamera-Erlaubnis) */
private fun torchCameraId(context: Context): String? = runCatching {
    val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    cm.cameraIdList.firstOrNull { id ->
        cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
    }
}.getOrNull()

private fun openSettingsPage(context: Context, action: String) {
    runCatching { context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

/** Das WLAN-Schnellfenster von Android (ab Android 10), sonst die WLAN-Einstellungen */
private fun openWifiPanel(context: Context) {
    val action = if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS
    openSettingsPage(context, action)
}

private fun openWriteSettings(context: Context) {
    runCatching {
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
