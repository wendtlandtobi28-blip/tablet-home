package com.example.tablethome

import android.content.Context

/** Höchstens so viele Apps stehen in der Startreihe */
const val MAX_DOCK = 6

/** Alles, was sich der Launcher merkt (SharedPreferences "tablethome") */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("tablethome", Context.MODE_PRIVATE)

    /** Hintergrund: Vorgaben-Kennung oder "url:…" */
    var wallpaper: String
        get() = sp.getString("wallpaper", "desert") ?: "desert"
        set(value) = sp.edit().putString("wallpaper", value).apply()

    /** Eigene Bild-Adressen aus dem Internet */
    var customUrls: List<String>
        get() = (sp.getString("custom_urls", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(value) = sp.edit().putString("custom_urls", value.joinToString("\n")).apply()

    /** Uhr-Stil, siehe CLOCK_STYLES */
    var clockStyle: String
        get() = (sp.getString("clock_style", "fett") ?: "fett").takeIf { it in CLOCK_STYLES } ?: "fett"
        set(value) = sp.edit().putString("clock_style", value).apply()

    /** Reihenfolge der Infos oben rechts (auch die ausgeschalteten) */
    var widgetOrder: List<String>
        get() {
            val saved = (sp.getString("widget_order", "") ?: "").split(",").filter { it in WIDGETS }
            return saved + WIDGETS.keys.filter { it !in saved }
        }
        set(value) = sp.edit().putString("widget_order", value.joinToString(",")).apply()

    /** Welche Infos oben rechts eingeschaltet sind */
    var widgetsOn: Set<String>
        get() = (sp.getString("widgets_on", "weather,wifi,bt") ?: "")
            .split(",")
            .filter { it in WIDGETS }
            .toSet()
        set(value) = sp.edit().putString("widgets_on", value.joinToString(",")).apply()

    /** Bildschirm anlassen, solange der Launcher zu sehen ist */
    var keepAwake: Boolean
        get() = sp.getBoolean("keep_awake", true)
        set(value) = sp.edit().putBoolean("keep_awake", value).apply()

    /**
     * Startreihe als Paketnamen in Reihenfolge.
     * null = noch nichts gewählt, dann gilt die Vorgabe aus PINNED_KEYS.
     */
    var dock: List<String>?
        get() = if (sp.contains("dock")) {
            (sp.getString("dock", "") ?: "").split(",").filter { it.isNotBlank() }
        } else {
            null
        }
        set(value) {
            if (value == null) {
                sp.edit().remove("dock").apply()
            } else {
                sp.edit().putString("dock", value.joinToString(",")).apply()
            }
        }

    /** Ids der Widgets auf der Widget-Seite, in Reihenfolge */
    var widgetIds: List<Int>
        get() = (sp.getString("widget_ids", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
        set(value) = sp.edit().putString("widget_ids", value.joinToString(",")).apply()

    /** Ob Standort und Bluetooth schon einmal angefragt wurden */
    var askedPermissions: Boolean
        get() = sp.getBoolean("asked_permissions", false)
        set(value) = sp.edit().putBoolean("asked_permissions", value).apply()
}
