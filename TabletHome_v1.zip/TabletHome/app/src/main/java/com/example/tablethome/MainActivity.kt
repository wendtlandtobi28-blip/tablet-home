package com.example.tablethome

import android.Manifest
import android.appwidget.AppWidgetHost
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/** Ein App-Eintrag: Anzeigename und Paketname */
data class AppEntry(val label: String, val packageName: String)

/** Welche Ebene gerade über dem Startbildschirm liegt. NONE = Startbildschirm. */
enum class Overlay { NONE, DRAWER, SETTINGS, MENU, NOTIF, QUICK }

private const val WIDGET_HOST_ID = 4711

class MainActivity : ComponentActivity() {

    /** Wird bei jedem Zurückkehren erhöht: Apps neu laden und Schnelleinstellungen neu lesen */
    private var refresh by mutableIntStateOf(0)

    /** Wird erhöht, wenn der Launcher erneut gestartet wird (Home-Taste): zurück zum Startbildschirm */
    private var goHomeTick by mutableIntStateOf(0)

    private lateinit var prefs: Prefs
    private lateinit var statusReader: StatusReader
    private lateinit var widgetHost: AppWidgetHost

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        prefs = Prefs(this)
        statusReader = StatusReader(this)
        widgetHost = AppWidgetHost(this, WIDGET_HOST_ID)

        // Einmal fragen: Standort (für den WLAN-Namen) und Bluetooth
        if (!prefs.askedPermissions) {
            prefs.askedPermissions = true
            val wanted = mutableListOf<String>()
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                wanted += Manifest.permission.ACCESS_FINE_LOCATION
            }
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) {
                wanted += Manifest.permission.BLUETOOTH_CONNECT
            }
            if (wanted.isNotEmpty()) runCatching { requestPermissions(wanted.toTypedArray(), 1) }
        }

        checkForUpdate(this)

        val versionName = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }
            .getOrNull() ?: "?"

        setContent {
            val apps by produceState<List<AppEntry>?>(null, refresh) {
                value = withContext(Dispatchers.IO) { loadApps() }
            }
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherRoot(
                    apps = apps,
                    goHomeTick = goHomeTick,
                    resumeTick = refresh,
                    prefs = prefs,
                    host = widgetHost,
                    readStatus = { statusReader.read() },
                    onLaunch = ::launchApp,
                    onBarIcons = ::setBarIcons,
                    versionName = versionName,
                    onCheckUpdate = { checkForUpdate(this@MainActivity) },
                    onInstallUpdate = { installFromUrl(this@MainActivity, UPDATE_APK_URL) },
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        widgetHost.startListening()
    }

    override fun onStop() {
        super.onStop()
        widgetHost.stopListening()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        goHomeTick++
    }

    override fun onResume() {
        super.onResume()
        refresh++
    }

    override fun onDestroy() {
        statusReader.close()
        super.onDestroy()
    }

    private fun setBarIcons(dark: Boolean) {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.isAppearanceLightStatusBars = dark
        controller.isAppearanceLightNavigationBars = dark
    }

    /** Nur Name und Paket, ohne Symbole, deshalb schnell */
    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(launcher, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun launchApp(app: AppEntry) {
        val intent = packageManager.getLaunchIntentForPackage(app.packageName) ?: return
        runCatching { startActivity(intent) }
    }
}

/** Ohne eigene Auswahl: die Apps aus PINNED_KEYS, in dieser Reihenfolge */
private fun pickPinned(apps: List<AppEntry>): List<AppEntry> {
    val named = apps.map { it to it.label.lowercase(Locale.getDefault()) }
    return PINNED_KEYS.mapNotNull { key ->
        named.firstOrNull { it.second.startsWith(key) }?.first
            ?: named.firstOrNull { it.second.contains(key) }?.first
    }.distinctBy { it.packageName }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LauncherRoot(
    apps: List<AppEntry>?,
    goHomeTick: Int,
    resumeTick: Int,
    prefs: Prefs,
    host: AppWidgetHost,
    readStatus: () -> DeviceStatus,
    onLaunch: (AppEntry) -> Unit,
    onBarIcons: (Boolean) -> Unit,
    versionName: String,
    onCheckUpdate: () -> Unit,
    onInstallUpdate: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val pagerState = rememberPagerState(pageCount = { 2 })

    var overlay by remember { mutableStateOf(Overlay.NONE) }
    var wallpaper by remember { mutableStateOf(prefs.wallpaper) }
    var customUrls by remember { mutableStateOf(prefs.customUrls) }
    var clockStyle by remember { mutableStateOf(prefs.clockStyle) }
    var widgetOrder by remember { mutableStateOf(prefs.widgetOrder) }
    var widgetsOn by remember { mutableStateOf(prefs.widgetsOn) }
    var keepAwake by remember { mutableStateOf(prefs.keepAwake) }
    var dockKeys by remember { mutableStateOf(prefs.dock) }

    // Home-Taste oder erneuter Start: zurück zum Startbildschirm
    LaunchedEffect(goHomeTick) {
        if (goHomeTick > 0) {
            overlay = Overlay.NONE
            pagerState.animateScrollToPage(0)
        }
    }

    // Der Bildschirm bleibt an, solange der Launcher zu sehen ist
    val view = LocalView.current
    DisposableEffect(keepAwake) {
        view.keepScreenOn = keepAwake
        onDispose { view.keepScreenOn = false }
    }

    // Abstände für die Statusleiste oben und die Navigationsleiste unten
    val density = LocalDensity.current
    val statusBarInsets = WindowInsets.statusBars
    val navBarInsets = WindowInsets.navigationBars
    val topInset: Dp = with(density) { statusBarInsets.getTop(this).toDp() }
    val bottomInset: Dp = with(density) { navBarInsets.getBottom(this).toDp() }

    // Alle Apps, und daraus die Startreihe
    val list = apps ?: emptyList()
    val dock = remember(list, dockKeys) {
        val keys = dockKeys
        if (keys != null) {
            keys.mapNotNull { key -> list.firstOrNull { it.packageName == key } }
        } else {
            pickPinned(list)
        }
    }
    val dockPackages = dock.map { it.packageName }

    val remoteUrl = if (wallpaper.startsWith("url:")) wallpaper.removePrefix("url:") else null
    val remoteImage = rememberRemoteImage(remoteUrl)
    val lightBg = PRESETS.firstOrNull { it.key == wallpaper }?.light == true
    val fg = if (lightBg) Color(0xFF1C1C1E) else Color.White
    val dimColor = Color(if (lightBg) 0xA6000000 else 0x80000000)

    // Uhr, Status und Wetter als State weitergeben: so zeichnet sich pro Sekunde nur die Anzeige neu
    val nowState = rememberNow()
    val statusState = produceState(DeviceStatus()) {
        while (true) {
            value = readStatus()
            delay(5_000)
        }
    }
    val weatherState = produceState<Weather?>(null) {
        while (true) {
            val w = withContext(Dispatchers.IO) { loadWeather() }
            if (w != null) value = w
            delay(if (w != null) 30 * 60_000L else 2 * 60_000L)
        }
    }

    // Alle 6 Stunden im Hintergrund nach Updates schauen
    LaunchedEffect(Unit) {
        while (true) {
            delay(6 * 60 * 60_000L)
            checkForUpdate(context)
        }
    }

    // Statusleiste: dunkle Symbole auf hellem Hintergrund, sonst helle
    val barsDark = overlay == Overlay.NONE && (lightBg || wallpaper == "desert")
    LaunchedEffect(barsDark) { onBarIcons(barsDark) }

    // Zurück schließt das offene Fenster. Auf den Widgets geht es zurück zum Startbildschirm.
    // Auf dem Startbildschirm passiert nichts.
    BackHandler {
        if (overlay != Overlay.NONE) {
            overlay = Overlay.NONE
        } else if (pagerState.currentPage != 0) {
            scope.launch { pagerState.animateScrollToPage(0) }
        }
    }

    // Änderungen aus den Einstellungen: sofort anzeigen und speichern
    val onClockStyle: (String) -> Unit = { style ->
        clockStyle = style
        prefs.clockStyle = style
    }
    val onWallpaper: (String) -> Unit = { key ->
        wallpaper = key
        prefs.wallpaper = key
    }
    val onAddUrl: (String) -> Unit = { url ->
        if (url !in customUrls) {
            customUrls = customUrls + url
            prefs.customUrls = customUrls
        }
        wallpaper = "url:$url"
        prefs.wallpaper = wallpaper
    }
    val onRemoveUrl: (String) -> Unit = { url ->
        customUrls = customUrls - url
        prefs.customUrls = customUrls
        if (wallpaper == "url:$url") {
            wallpaper = "desert"
            prefs.wallpaper = wallpaper
        }
    }
    val onToggleWidget: (String) -> Unit = { id ->
        widgetsOn = if (id in widgetsOn) widgetsOn - id else widgetsOn + id
        prefs.widgetsOn = widgetsOn
    }
    val onMoveWidget: (String, Int) -> Unit = { id, delta ->
        val i = widgetOrder.indexOf(id)
        val j = (i + delta).coerceIn(0, widgetOrder.size - 1)
        if (i >= 0 && i != j) {
            val moved = widgetOrder.toMutableList()
            moved.removeAt(i)
            moved.add(j, id)
            widgetOrder = moved
            prefs.widgetOrder = moved
        }
    }
    val onToggleKeepAwake: () -> Unit = {
        keepAwake = !keepAwake
        prefs.keepAwake = keepAwake
    }
    val onDockChange: (List<String>) -> Unit = { keys ->
        dockKeys = keys
        prefs.dock = keys
    }
    val onResetDock: () -> Unit = {
        dockKeys = null
        prefs.dock = null
    }

    Box(Modifier.fillMaxSize()) {
        Background(key = wallpaper, image = remoteImage)

        CompositionLocalProvider(LocalFg provides fg) {
            HomeScreen(
                pagerState = pagerState,
                interactive = overlay == Overlay.NONE,
                nowState = nowState,
                clockStyle = clockStyle,
                widgets = widgetOrder.filter { it in widgetsOn },
                statusState = statusState,
                weatherState = weatherState,
                dock = dock,
                loaded = apps != null,
                topInset = topInset,
                bottomInset = bottomInset,
                host = host,
                prefs = prefs,
                onLaunch = onLaunch,
                onAllApps = { overlay = Overlay.DRAWER },
                onNotif = { overlay = Overlay.NOTIF },
                onQuick = { overlay = Overlay.QUICK },
                onMenu = { overlay = Overlay.MENU },
                onUpdate = { overlay = Overlay.SETTINGS },
            )
        }

        // Abdunkeln. Tippen daneben schließt das Fenster.
        AnimatedVisibility(
            visible = overlay != Overlay.NONE,
            modifier = Modifier.fillMaxSize(),
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(dimColor)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        overlay = Overlay.NONE
                    },
            )
        }

        // Mitteilungen: von oben links
        AnimatedVisibility(
            visible = overlay == Overlay.NOTIF,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 16.dp, top = topInset + 8.dp),
            enter = slideInVertically() + fadeIn(),
            exit = slideOutVertically() + fadeOut(),
        ) {
            NotificationPanel(
                onClose = { overlay = Overlay.NONE },
                resumeTick = resumeTick,
                modifier = Modifier.width(460.dp).fillMaxHeight(0.75f),
            )
        }

        // Schnelleinstellungen: von oben rechts
        AnimatedVisibility(
            visible = overlay == Overlay.QUICK,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 16.dp, top = topInset + 8.dp),
            enter = slideInVertically() + fadeIn(),
            exit = slideOutVertically() + fadeOut(),
        ) {
            QuickPanel(
                onClose = { overlay = Overlay.NONE },
                resumeTick = resumeTick,
                modifier = Modifier.width(440.dp),
            )
        }

        // Menü bei langem Drücken auf eine freie Stelle
        AnimatedVisibility(
            visible = overlay == Overlay.MENU,
            modifier = Modifier.align(Alignment.Center),
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            HomeMenu(
                onWidgets = {
                    overlay = Overlay.NONE
                    scope.launch { pagerState.animateScrollToPage(1) }
                },
                onAllApps = { overlay = Overlay.DRAWER },
                onSettings = { overlay = Overlay.SETTINGS },
                onHomeApp = {
                    overlay = Overlay.NONE
                    openHomeAppSettings(context)
                },
            )
        }

        // Alle Apps: ganzer Bildschirm
        AnimatedVisibility(
            visible = overlay == Overlay.DRAWER,
            modifier = Modifier.fillMaxSize(),
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            AllAppsOverlay(
                apps = list,
                dock = dockPackages,
                topInset = topInset,
                bottomInset = bottomInset,
                onLaunch = onLaunch,
                onSettings = { overlay = Overlay.SETTINGS },
                onClose = { overlay = Overlay.NONE },
                onDockChange = onDockChange,
            )
        }

        // Einstellungen: ganzer Bildschirm
        AnimatedVisibility(
            visible = overlay == Overlay.SETTINGS,
            modifier = Modifier.fillMaxSize(),
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            SettingsOverlay(
                topInset = topInset,
                bottomInset = bottomInset,
                nowState = nowState,
                clockStyle = clockStyle,
                onClockStyle = onClockStyle,
                wallpaper = wallpaper,
                customUrls = customUrls,
                onWallpaper = onWallpaper,
                onAddUrl = onAddUrl,
                onRemoveUrl = onRemoveUrl,
                widgetOrder = widgetOrder,
                widgetsOn = widgetsOn,
                onToggleWidget = onToggleWidget,
                onMoveWidget = onMoveWidget,
                onShowWidgets = {
                    overlay = Overlay.NONE
                    scope.launch { pagerState.animateScrollToPage(1) }
                },
                keepAwake = keepAwake,
                onToggleKeepAwake = onToggleKeepAwake,
                dock = dock,
                onResetDock = onResetDock,
                versionName = versionName,
                resumeTick = resumeTick,
                onCheckUpdate = onCheckUpdate,
                onInstallUpdate = onInstallUpdate,
                onBack = { overlay = Overlay.NONE },
            )
        }
    }
}
