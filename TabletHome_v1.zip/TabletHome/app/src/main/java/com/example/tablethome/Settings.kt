package com.example.tablethome

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import java.time.LocalDateTime

/**
 * Einstellungen des Launchers. Sie gestalten nur den Startbildschirm,
 * die Einstellungen von Samsung bleiben unberührt.
 */
@Composable
fun SettingsOverlay(
    topInset: Dp,
    bottomInset: Dp,
    nowState: State<LocalDateTime>,
    clockStyle: String,
    onClockStyle: (String) -> Unit,
    wallpaper: String,
    customUrls: List<String>,
    onWallpaper: (String) -> Unit,
    onAddUrl: (String) -> Unit,
    onRemoveUrl: (String) -> Unit,
    widgetOrder: List<String>,
    widgetsOn: Set<String>,
    onToggleWidget: (String) -> Unit,
    onMoveWidget: (String, Int) -> Unit,
    onShowWidgets: () -> Unit,
    keepAwake: Boolean,
    onToggleKeepAwake: () -> Unit,
    dock: List<AppEntry>,
    onResetDock: () -> Unit,
    versionName: String,
    resumeTick: Int,
    onCheckUpdate: () -> Unit,
    onInstallUpdate: () -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val listenerOn = remember(resumeTick) {
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            .verticalScroll(rememberScrollState())
            .padding(start = 44.dp, end = 44.dp, top = topInset + 24.dp, bottom = bottomInset + 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "Einstellungen", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            ChipButton(text = "Zurück", onClick = onBack)
        }
        Text(
            text = "Hier gestaltest du nur den Startbildschirm. Die Einstellungen von Samsung bleiben wie gewohnt.",
            color = Color(0xB3FFFFFF),
            fontSize = 15.sp,
        )

        // ---- Uhr
        SectionTitle("Uhr")
        ClockPreview(nowState = nowState, style = clockStyle)
        CLOCK_STYLES.entries.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { (key, label) ->
                    ChipButton(
                        text = (if (key == clockStyle) "✓  " else "") + label,
                        onClick = { onClockStyle(key) },
                        modifier = Modifier.weight(1f),
                    )
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }

        // ---- Hintergrund
        SectionTitle("Hintergrund")
        PRESETS.chunked(5).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { preset ->
                    ChipButton(
                        text = (if (wallpaper == preset.key) "✓  " else "") + preset.label,
                        onClick = { onWallpaper(preset.key) },
                        modifier = Modifier.weight(1f),
                    )
                }
                repeat(5 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        customUrls.forEach { url ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                ChipButton(
                    text = (if (wallpaper == "url:$url") "✓  " else "") + url.take(70),
                    onClick = { onWallpaper("url:$url") },
                    modifier = Modifier.weight(1f),
                )
                ChipButton(text = "Entfernen", onClick = { onRemoveUrl(url) })
            }
        }
        BasicTextField(
            value = input,
            onValueChange = {
                input = it
                error = null
            },
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0x26FFFFFF))
                .padding(horizontal = 18.dp, vertical = 14.dp),
            decorationBox = { inner ->
                Box {
                    if (input.isEmpty()) {
                        Text(
                            text = "Adresse eingeben, z. B. https://…",
                            color = Color(0x80FFFFFF),
                            fontSize = 18.sp,
                        )
                    }
                    inner()
                }
            },
        )
        ChipButton(
            text = "Bild hinzufügen",
            onClick = {
                val url = input.trim()
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    onAddUrl(url)
                    input = ""
                } else {
                    error = "Die Adresse muss mit https:// beginnen."
                }
            },
        )
        error?.let { Text(text = it, color = Color(0xFFFF8A80), fontSize = 15.sp) }
        Text(
            text = "Bilder werden aus dem Internet geladen. Nutze nur Bilder, die du verwenden darfst.",
            color = Color(0x80FFFFFF),
            fontSize = 14.sp,
        )

        // ---- Startseite: Infos oben rechts und Widgets
        SectionTitle("Startseite")
        ChipButton(text = "Widget-Seite öffnen", onClick = onShowWidgets)
        Text(
            text = "Die Infos oben rechts erscheinen von oben nach unten in dieser Reihenfolge.",
            color = Color(0xB3FFFFFF),
            fontSize = 15.sp,
        )
        widgetOrder.forEach { id ->
            val on = id in widgetsOn
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                ChipButton(
                    text = (if (on) "✓  " else "○  ") + (WIDGETS[id] ?: id),
                    onClick = { onToggleWidget(id) },
                    modifier = Modifier.weight(1f),
                )
                ChipButton(text = "▲", onClick = { onMoveWidget(id, -1) })
                ChipButton(text = "▼", onClick = { onMoveWidget(id, 1) })
            }
        }

        // ---- Bildschirm
        SectionTitle("Bildschirm")
        ChipButton(
            text = "Ruhemodus verhindern: " + (if (keepAwake) "an" else "aus"),
            onClick = onToggleKeepAwake,
        )
        Text(
            text = "Solange der Startbildschirm zu sehen ist, geht das Tablet nicht in den Ruhemodus.",
            color = Color(0xB3FFFFFF),
            fontSize = 15.sp,
        )

        // ---- Startreihe
        SectionTitle("Startreihe")
        Text(
            text = "Unten auf dem Startbildschirm: " + (if (dock.isEmpty()) "leer" else dock.joinToString(", ") { it.label }),
            color = Color(0xB3FFFFFF),
            fontSize = 15.sp,
        )
        Text(
            text = "Apps hinzufügen oder entfernen: Im Menü „Alle Apps“ eine App lange drücken.",
            color = Color(0xB3FFFFFF),
            fontSize = 15.sp,
        )
        ChipButton(text = "Auf Vorgabe zurücksetzen", onClick = onResetDock)

        // ---- Mitteilungen
        SectionTitle("Mitteilungen")
        Text(
            text = "Zugriff auf Mitteilungen: " + (if (listenerOn) "erlaubt ✓" else "nicht erlaubt"),
            color = Color(0xB3FFFFFF),
            fontSize = 15.sp,
        )
        ChipButton(text = "Mitteilungs-Zugriff öffnen", onClick = { openListenerSettings(context) })

        // ---- Standard-Startapp
        SectionTitle("Standard-Startapp")
        ChipButton(text = "Startapp festlegen", onClick = { openHomeAppSettings(context) })
        Text(
            text = "Hier wählst du Tablet Home als Startbildschirm oder wieder den von Samsung.",
            color = Color(0xB3FFFFFF),
            fontSize = 15.sp,
        )

        // ---- Software-Update, unabhängig von Samsung
        SectionTitle("Software-Update")
        Text(text = "Installierte Version: $versionName", color = Color.White, fontSize = 16.sp)
        Text(text = UpdateState.status, color = Color(0xB3FFFFFF), fontSize = 15.sp)
        ChipButton(text = "Nach Update suchen", onClick = onCheckUpdate)
        ChipButton(
            text = if (UpdateState.available) "Update jetzt installieren" else "Trotzdem neu installieren",
            onClick = onInstallUpdate,
        )
        Text(
            text = "Updates kommen von GitHub. Beim Update bleiben alle Daten und Einstellungen erhalten: " +
                "Uhr, Widgets, Hintergrund und Startreihe.",
            color = Color(0x80FFFFFF),
            fontSize = 14.sp,
        )
        Spacer(Modifier.height(40.dp))
    }
}

/** Öffnet Androids Auswahl für die Startapp (Tablet Home oder Samsung) */
fun openHomeAppSettings(context: Context) {
    runCatching {
        context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        color = Color(0xB3FFFFFF),
        fontSize = 16.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 10.dp),
    )
}

/** Kleine Vorschau der gewählten Uhr */
@Composable
private fun ClockPreview(nowState: State<LocalDateTime>, style: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0x33000000)),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.scale(if (style == "analog") 0.6f else 0.7f)) {
            LiveClock(nowState = nowState, style = style)
        }
    }
}
