package com.example.tablethome

import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.sin

/** Diese Apps stehen ganz vorn, in dieser Reihenfolge. Fehlende werden übersprungen. */
val PINNED_KEYS = listOf("netflix", "prime video", "joyn", "youtube")

/** Hintergrund-Vorgabe. [light] = heller Hintergrund, dann wird die Schrift dunkel. */
data class Preset(val key: String, val label: String, val colors: List<Color>?, val light: Boolean = false)

/** Eigene Hintergründe, bewusst ohne fremde Bilder. */
val PRESETS = listOf(
    Preset("desert", "Wüste", null),
    Preset("black", "Schwarz", listOf(Color(0xFF16161A), Color(0xFF000000))),
    Preset("white", "Weiß", listOf(Color(0xFFFFFFFF), Color(0xFFE4E5EA)), light = true),
    Preset("blue", "Blau", listOf(Color(0xFF2F7BFF), Color(0xFF0D2B6E), Color(0xFF050B1C))),
    Preset("red", "Rot", listOf(Color(0xFFE53935), Color(0xFF6E1010), Color(0xFF1A0404))),
    Preset("orange", "Orange", listOf(Color(0xFFFF8A2A), Color(0xFF8C3A0A), Color(0xFF1C0A03))),
    Preset("pink", "Pink", listOf(Color(0xFFFF5FA8), Color(0xFF7A1E4F), Color(0xFF1A0712))),
    Preset("green", "Grün", listOf(Color(0xFF34B36A), Color(0xFF0E4A2A), Color(0xFF04140B))),
    Preset("violet", "Violett", listOf(Color(0xFF9B6BFF), Color(0xFF3A1E7A), Color(0xFF0D0620))),
    Preset("aurora", "Aurora", listOf(Color(0xFF0B3D4F), Color(0xFF2A1B4D), Color(0xFF0B0B10))),
    Preset("dusk", "Dämmerung", listOf(Color(0xFF7A2E3A), Color(0xFF3A1E4F), Color(0xFF0B0B10))),
    Preset("ocean", "Ozean", listOf(Color(0xFF0E4D6B), Color(0xFF0B2A3F), Color(0xFF07131E))),
    Preset("night", "Nacht", listOf(Color(0xFF1B2140), Color(0xFF0B0E1C), Color(0xFF05060C))),
    Preset("forest", "Wald", listOf(Color(0xFF1E4A3A), Color(0xFF0F2A22), Color(0xFF060F0C))),
)

/** Uhr-Stile: Kennung -> Name */
val CLOCK_STYLES = linkedMapOf(
    "fett" to "Fett (Apple-Stil)",
    "fett_datum" to "Fett mit Datum",
    "mittel" to "Mittel",
    "duenn" to "Dünn",
    "sekunden" to "Mit Sekunden",
    "analog" to "Analog",
)

private fun downloadBitmap(url: String): ImageBitmap? = runCatching {
    val connection = URL(url).openConnection() as HttpURLConnection
    connection.connectTimeout = 10_000
    connection.readTimeout = 20_000
    connection.instanceFollowRedirects = true
    connection.inputStream.use { stream ->
        BitmapFactory.decodeStream(stream, null, BitmapFactory.Options().apply { inSampleSize = 2 })
    }?.asImageBitmap()
}.getOrNull()

@Composable
fun rememberRemoteImage(url: String?): ImageBitmap? {
    val image by produceState<ImageBitmap?>(initialValue = null, key1 = url) {
        value = if (url != null) withContext(Dispatchers.IO) { downloadBitmap(url) } else null
    }
    return image
}

/** Aktuelle Zeit, genau zum Sekundenwechsel aktualisiert. */
@Composable
fun rememberNow(): State<LocalDateTime> =
    produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(1_000L - (System.currentTimeMillis() % 1_000L))
        }
    }

@Composable
fun Background(key: String, image: ImageBitmap?) {
    if (key.startsWith("url:") && image != null) {
        Image(
            bitmap = image,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        Box(Modifier.fillMaxSize().background(Color(0x55000000)))
        return
    }
    val preset = PRESETS.firstOrNull { it.key == key }?.colors
    if (preset == null) {
        DesertBackground()
        return
    }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(preset))) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.radialGradient(listOf(preset.first().copy(alpha = 0.45f), Color.Transparent), radius = 1300f))
        )
    }
}

/** Eigene Wüstenszene: heller Himmel, warmer Dunst und mehrere Dünenlagen. */
@Composable
private fun DesertBackground() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF8DBDEB), Color(0xFFC4DCF0), Color(0xFFF1E4CF)),
                startY = 0f,
                endY = h * 0.6f,
            ),
        )
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0x00F1E4CF), Color(0xB3F1E4CF)),
                startY = h * 0.42f,
                endY = h * 0.72f,
            ),
        )
        drawDune(w, h, h * 0.56f, h * 0.025f, 1.3f, 0.4f, Color(0xFFE6D3B3), Color(0xFFD6B48B))
        drawDune(w, h, h * 0.66f, h * 0.04f, 1.8f, 2.1f, Color(0xFFD9BB92), Color(0xFFC39A6C))
        drawDune(w, h, h * 0.79f, h * 0.05f, 1.1f, 4.0f, Color(0xFFC9A074), Color(0xFFAD8052))
        drawDune(w, h, h * 0.93f, h * 0.06f, 0.9f, 5.3f, Color(0xFFB38758), Color(0xFF94663F))
    }
}

private fun DrawScope.drawDune(
    w: Float, h: Float, baseY: Float, amp: Float, freq: Float, phase: Float, top: Color, bottom: Color,
) {
    val path = Path()
    path.moveTo(0f, h)
    val steps = 80
    for (i in 0..steps) {
        val x = w * i / steps
        val t = x / w * 2f * PI.toFloat()
        val y = baseY + amp * (sin(t * freq + phase) * 0.7f + sin(t * freq * 2.3f + phase * 1.7f) * 0.3f)
        path.lineTo(x, y)
    }
    path.lineTo(w, h)
    path.close()
    drawPath(path = path, brush = Brush.verticalGradient(listOf(top, bottom), startY = baseY - amp, endY = h))
}

private val DE_LOCALE = Locale.GERMANY

/** Uhr, die die Zeit selbst liest. Nur sie wird jede Sekunde neu gezeichnet. */
@Composable
fun LiveClock(nowState: State<LocalDateTime>, style: String, modifier: Modifier = Modifier) {
    Clock(now = nowState.value, style = style, modifier = modifier)
}

/** Große Uhr in verschiedenen Stilen. Zeigt die echte Uhrzeit. */
@Composable
fun Clock(now: LocalDateTime, style: String, modifier: Modifier = Modifier) {
    val fg = LocalFg.current
    if (style == "analog") {
        AnalogClock(now = now, color = fg, modifier = modifier.size(250.dp))
        return
    }
    val (weight, size, pattern) = when (style) {
        "mittel" -> Triple(FontWeight.Medium, 160, "H:mm")
        "duenn" -> Triple(FontWeight.Thin, 180, "H:mm")
        "sekunden" -> Triple(FontWeight.Bold, 120, "H:mm:ss")
        else -> Triple(FontWeight.Black, 150, "H:mm")   // fett, fett_datum
    }
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = DateTimeFormatter.ofPattern(pattern).format(now),
            color = fg,
            fontSize = size.sp,
            fontWeight = weight,
            letterSpacing = (-3).sp,
            maxLines = 1,
            style = TextStyle(shadow = Shadow(color = Color(0x33000000), blurRadius = 24f)),
        )
        if (style == "fett_datum") {
            Text(
                text = DateTimeFormatter.ofPattern("EEEE, d. MMMM", DE_LOCALE).format(now),
                color = fg,
                fontSize = 28.sp,
                fontWeight = FontWeight.SemiBold,
                style = TextStyle(shadow = Shadow(color = Color(0x33000000), blurRadius = 16f)),
            )
        }
    }
}

@Composable
private fun AnalogClock(now: LocalDateTime, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height / 2)
        val r = size.minDimension / 2
        drawCircle(Color(0x33000000), radius = r, center = c)
        drawCircle(color.copy(alpha = 0.6f), radius = r, center = c, style = Stroke(width = r * 0.025f))
        for (k in 0 until 12) {
            rotate(k * 30f, c) {
                drawLine(
                    color = color,
                    start = Offset(c.x, c.y - r * 0.92f),
                    end = Offset(c.x, c.y - r * (if (k % 3 == 0) 0.76f else 0.84f)),
                    strokeWidth = r * (if (k % 3 == 0) 0.04f else 0.022f),
                    cap = StrokeCap.Round,
                )
            }
        }
        val minutes = now.minute + now.second / 60f
        val hours = (now.hour % 12) + minutes / 60f
        rotate(hours * 30f, c) {
            drawLine(color, c, Offset(c.x, c.y - r * 0.5f), strokeWidth = r * 0.06f, cap = StrokeCap.Round)
        }
        rotate(minutes * 6f, c) {
            drawLine(color, c, Offset(c.x, c.y - r * 0.75f), strokeWidth = r * 0.04f, cap = StrokeCap.Round)
        }
        rotate(now.second * 6f, c) {
            drawLine(Color(0xFFFF9F0A), Offset(c.x, c.y + r * 0.12f), Offset(c.x, c.y - r * 0.82f), strokeWidth = r * 0.015f, cap = StrokeCap.Round)
        }
        drawCircle(Color(0xFFFF9F0A), radius = r * 0.035f, center = c)
    }
}
