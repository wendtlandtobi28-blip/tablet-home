@file:Suppress("DEPRECATION")

package com.example.tablethome

import android.app.PendingIntent
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.ConnectivityManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import kotlin.concurrent.thread

// ======================= Einstellungen =======================

/** Wetter für Hamburg-Volksdorf */
const val WEATHER_PLACE = "Volksdorf"
const val WEATHER_LAT = 53.65
const val WEATHER_LON = 10.16

/** Hier holt sich der Launcher seine Updates (dein GitHub-Repo) */
const val GITHUB_REPO = "wendtlandtobi28-blip/tablet-home"
const val UPDATE_APK_URL = "https://github.com/$GITHUB_REPO/releases/download/latest/app-debug.apk"

// ======================= Status (WLAN + Bluetooth) =======================

data class DeviceStatus(
    val wifiName: String = "WLAN",
    val wifiDetail: String = "",
    val btName: String = "Bluetooth",
    val btDetail: String = "",
    /** 0 = kein WLAN, 1..3 = Balken */
    val wifiLevel: Int = 0,
    val btConnected: Boolean = false,
)

class StatusReader(private val context: Context) {
    private var a2dp: BluetoothA2dp? = null

    init {
        runCatching {
            BluetoothAdapter.getDefaultAdapter()?.getProfileProxy(
                context,
                object : BluetoothProfile.ServiceListener {
                    override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                        a2dp = proxy as BluetoothA2dp
                    }

                    override fun onServiceDisconnected(profile: Int) {
                        a2dp = null
                    }
                },
                BluetoothProfile.A2DP,
            )
        }
    }

    fun read(): DeviceStatus {
        var wifiName = "WLAN"
        var wifiDetail = ""
        var wifiLevel = 0
        runCatching {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val ni = cm.activeNetworkInfo
            if (ni == null || !ni.isConnected) {
                wifiName = "Nicht verbunden"
                wifiDetail = "WLAN"
            } else if (ni.type == ConnectivityManager.TYPE_ETHERNET) {
                wifiName = "LAN-Kabel"
                wifiDetail = "verbunden"
                wifiLevel = 3
            } else {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val info = wm.connectionInfo
                var ssid = info.ssid ?: ""
                if (ssid.isBlank() || ssid.contains("unknown ssid")) ssid = "WLAN verbunden"
                wifiName = ssid.replace("\"", "")
                val pct = WifiManager.calculateSignalLevel(info.rssi, 101).coerceIn(0, 100)
                wifiDetail = "Signal $pct %"
                wifiLevel = when {
                    pct >= 67 -> 3
                    pct >= 34 -> 2
                    else -> 1
                }
            }
        }

        var btName = "Bluetooth"
        var btDetail = ""
        var btConnected = false
        runCatching {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null || !adapter.isEnabled) {
                btName = "Bluetooth aus"
            } else {
                val device = a2dp?.connectedDevices?.firstOrNull()
                if (device == null) {
                    btName = "Kein Gerät"
                    btDetail = "Bluetooth"
                } else {
                    btName = device.name ?: "Gerät"
                    btDetail = "verbunden"
                    btConnected = true
                }
            }
        }
        return DeviceStatus(wifiName, wifiDetail, btName, btDetail, wifiLevel, btConnected)
    }

    fun close() {
        runCatching { a2dp?.let { BluetoothAdapter.getDefaultAdapter()?.closeProfileProxy(BluetoothProfile.A2DP, it) } }
    }
}

// ======================= Wetter (Open-Meteo, ohne Anmeldung) =======================

data class Weather(val text: String, val code: Int)

fun loadWeather(): Weather? = runCatching {
    val url = URL(
        "https://api.open-meteo.com/v1/forecast?latitude=$WEATHER_LAT&longitude=$WEATHER_LON" +
            "&current=temperature_2m,weather_code&timezone=Europe%2FBerlin"
    )
    val con = url.openConnection() as HttpURLConnection
    con.connectTimeout = 10_000
    con.readTimeout = 10_000
    val body = con.inputStream.bufferedReader().use { it.readText() }
    val cur = JSONObject(body).getJSONObject("current")
    val temp = Math.round(cur.getDouble("temperature_2m"))
    val code = cur.getInt("weather_code")
    Weather("$temp °C · ${weatherText(code)}", code)
}.getOrNull()

private fun weatherText(c: Int) = when (c) {
    0 -> "klar"
    1 -> "heiter"
    2 -> "leicht bewölkt"
    3 -> "bewölkt"
    45, 48 -> "Nebel"
    in 51..57 -> "Niesel"
    in 61..67 -> "Regen"
    in 71..77 -> "Schnee"
    in 80..82 -> "Schauer"
    85, 86 -> "Schneeschauer"
    in 95..99 -> "Gewitter"
    else -> ""
}

// ======================= Infos rechts =======================

/** Schriftfarbe auf dem Startbildschirm (dunkel bei hellen Hintergründen) */
val LocalFg = compositionLocalOf { Color.White }

/** Alle Widgets, die es gibt: Kennung -> Name in den Einstellungen */
val WIDGETS = linkedMapOf(
    "weather" to "Wetter",
    "wifi" to "WLAN",
    "bt" to "Bluetooth",
    "date" to "Datum",
)

private val GERMAN = java.util.Locale.GERMANY

@Composable
fun InfoPanel(
    widgets: List<String>,
    statusState: androidx.compose.runtime.State<DeviceStatus>,
    weatherState: androidx.compose.runtime.State<Weather?>,
    nowState: androidx.compose.runtime.State<java.time.LocalDateTime>,
    modifier: Modifier = Modifier,
) {
    val status = statusState.value
    val weather = weatherState.value
    // Nur das Datum beobachten: das Panel wird so nur einmal am Tag neu gezeichnet, nicht jede Sekunde
    val today by remember { androidx.compose.runtime.derivedStateOf { nowState.value.toLocalDate() } }
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.End,
    ) {
        widgets.forEach { id ->
            when (id) {
                "weather" -> InfoRow(weather?.text ?: "Wetter lädt …", WEATHER_PLACE) { WeatherIcon(weather?.code ?: 3) }
                "wifi" -> InfoRow(status.wifiName, status.wifiDetail) { WifiIcon(status.wifiLevel) }
                "bt" -> InfoRow(status.btName, status.btDetail) { SoundIcon(status.btConnected) }
                "date" -> InfoRow(
                    today.format(java.time.format.DateTimeFormatter.ofPattern("EEEE", GERMAN)),
                    today.format(java.time.format.DateTimeFormatter.ofPattern("d. MMMM yyyy", GERMAN)),
                ) { CalendarIcon(today.dayOfMonth) }
            }
        }
    }
}

private val infoShadow = Shadow(color = Color(0x66000000), blurRadius = 12f)

@Composable
private fun InfoRow(top: String, sub: String, icon: @Composable () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        val fg = LocalFg.current
        Column(horizontalAlignment = Alignment.End, modifier = Modifier.width(210.dp)) {
            Text(
                text = top,
                color = fg,
                fontSize = 20.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.End,
                style = TextStyle(shadow = infoShadow),
            )
            if (sub.isNotEmpty()) {
                Text(
                    text = sub,
                    color = fg.copy(alpha = 0.85f),
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.End,
                    style = TextStyle(shadow = infoShadow),
                )
            }
        }
        Spacer(Modifier.width(14.dp))
        // Symbol in einem runden Glas-Kreis, damit es auf jedem Hintergrund gut lesbar ist
        Box(
            modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0x47000000)),
            contentAlignment = Alignment.Center,
        ) { icon() }
    }
}

// ======================= Update =======================

/** Gemeinsamer Zustand für Update-Anzeige */
object UpdateState {
    var status by mutableStateOf("Noch nicht gesucht")
    var available by mutableStateOf(false)
    var busy by mutableStateOf(false)
}

private val mainHandler = Handler(Looper.getMainLooper())
private fun onMain(block: () -> Unit) { mainHandler.post { block() } }

/** Prüft auf GitHub, ob eine neuere APK als die installierte da ist. */
fun checkForUpdate(context: Context) {
    if (UpdateState.busy) return
    onMain { UpdateState.status = "Suche nach Update …" }
    thread {
        runCatching {
            val con = URL("https://api.github.com/repos/$GITHUB_REPO/releases/tags/latest")
                .openConnection() as HttpURLConnection
            con.setRequestProperty("User-Agent", "TabletHome-Launcher")
            con.setRequestProperty("Accept", "application/vnd.github+json")
            con.connectTimeout = 10_000
            con.readTimeout = 10_000
            val json = JSONObject(con.inputStream.bufferedReader().use { it.readText() })
            val assets = json.getJSONArray("assets")
            var newest = 0L
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.getString("name").endsWith(".apk")) {
                    newest = maxOf(newest, Instant.parse(a.getString("updated_at")).toEpochMilli())
                }
            }
            val installed = context.packageManager.getPackageInfo(context.packageName, 0).lastUpdateTime
            // Neue APK, wenn sie nach der Installation dieser Version gebaut wurde
            val hasNew = newest > installed + 60_000
            onMain {
                UpdateState.available = hasNew
                UpdateState.status = if (hasNew) "Neues Update verfügbar" else "Du hast die neueste Version"
            }
        }.onFailure {
            onMain { UpdateState.status = "Update-Suche fehlgeschlagen (Internet?)" }
        }
    }
}

/** Lädt eine APK herunter und startet die Installation (Bestätigen am Tablet). */
fun installFromUrl(context: Context, url: String) {
    if (UpdateState.busy) return
    val app = context.applicationContext
    // Sofort sperren (wir sind hier auf dem Haupt-Thread), damit ein Doppelklick nicht zwei Downloads startet
    UpdateState.busy = true
    UpdateState.status = "Update wird geladen …"
    thread {
        var sessionId = -1
        runCatching {
            if (Build.VERSION.SDK_INT >= 26 && !app.packageManager.canRequestPackageInstalls()) {
                onMain {
                    Toast.makeText(app, "Bitte Tablet Home erlauben, Apps zu installieren", Toast.LENGTH_LONG).show()
                    runCatching {
                        app.startActivity(
                            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${app.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            }
            val installer = app.packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            sessionId = installer.createSession(params)
            installer.openSession(sessionId).use { session ->
                val con = URL(url).openConnection() as HttpURLConnection
                con.instanceFollowRedirects = true
                con.connectTimeout = 15_000
                con.readTimeout = 60_000
                con.inputStream.use { input ->
                    session.openWrite("update.apk", 0, -1).use { out ->
                        input.copyTo(out)
                        session.fsync(out)
                    }
                }
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                val pending = PendingIntent.getBroadcast(
                    app, 0, Intent(app, InstallReceiver::class.java), flags
                )
                session.commit(pending.intentSender)
            }
            onMain { UpdateState.status = "Bitte am Tablet bestätigen" }
        }.onFailure {
            // Halb geladene Installation aufräumen
            if (sessionId != -1) runCatching { app.packageManager.packageInstaller.abandonSession(sessionId) }
            onMain {
                UpdateState.busy = false
                UpdateState.status = "Update fehlgeschlagen (Internet?)"
            }
        }
    }
}

/** Bekommt die Antwort vom System-Installer. */
class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -999)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                confirm?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { context.startActivity(confirm) }
            }
            PackageInstaller.STATUS_SUCCESS -> {
                UpdateState.busy = false
                UpdateState.status = "Update installiert"
            }
            else -> {
                UpdateState.busy = false
                val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "abgebrochen"
                UpdateState.status = "Update nicht installiert: $msg"
                Toast.makeText(context, "Update nicht installiert", Toast.LENGTH_LONG).show()
            }
        }
    }
}
