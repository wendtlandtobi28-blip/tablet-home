package com.example.tablethome

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

/** Ein Widget, das gerade hinzugefügt wird */
private class PendingWidget(val id: Int, val info: AppWidgetProviderInfo)

/** Seite 2: Widgets, zum Beispiel die Uhr von Samsung. Jedes Widget lässt sich entfernen. */
@Composable
fun WidgetPage(host: AppWidgetHost, prefs: Prefs, topPad: Dp, bottomPad: Dp) {
    val context = LocalContext.current
    val pm = context.packageManager
    val manager = remember { AppWidgetManager.getInstance(context) }
    var ids by remember { mutableStateOf(prefs.widgetIds) }
    var pending by remember { mutableStateOf<PendingWidget?>(null) }
    var picking by remember { mutableStateOf(false) }

    val onAdded: (Int) -> Unit = { id ->
        prefs.widgetIds = prefs.widgetIds + id
        ids = prefs.widgetIds
    }

    // Reihenfolge: erst binden (ggf. Erlaubnis), dann einrichten (falls das Widget Einstellungen hat)
    val configLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val p = pending
        pending = null
        if (p != null) {
            if (result.resultCode == Activity.RESULT_OK) onAdded(p.id) else host.deleteAppWidgetId(p.id)
        }
    }

    val bindLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val p = pending ?: return@rememberLauncherForActivityResult
        if (result.resultCode == Activity.RESULT_OK) {
            val component = p.info.configure
            if (component != null) {
                configLauncher.launch(configIntent(p.id, component))
            } else {
                pending = null
                onAdded(p.id)
            }
        } else {
            pending = null
            host.deleteAppWidgetId(p.id)
        }
    }

    val startBind: (AppWidgetProviderInfo) -> Unit = { info ->
        val id = host.allocateAppWidgetId()
        pending = PendingWidget(id, info)
        if (manager.bindAppWidgetIdIfAllowed(id, info.provider)) {
            val component = info.configure
            if (component != null) {
                configLauncher.launch(configIntent(id, component))
            } else {
                pending = null
                onAdded(id)
            }
        } else {
            bindLauncher.launch(
                Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            )
        }
    }

    val remove: (Int) -> Unit = { id ->
        host.deleteAppWidgetId(id)
        prefs.widgetIds = prefs.widgetIds - id
        ids = prefs.widgetIds
    }

    // Nur Widgets anzeigen, die wirklich noch da sind
    val infos = ids.mapNotNull { id -> manager.getAppWidgetInfo(id)?.let { info -> id to info } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 44.dp, end = 44.dp, top = topPad, bottom = bottomPad),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "Widgets", color = LocalFg.current, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            ChipButton(text = "Widget hinzufügen", onClick = { picking = true })
        }
        if (infos.isEmpty()) {
            Text(
                text = "Noch keine Widgets. Tippe auf „Widget hinzufügen“, zum Beispiel für die Uhr von Samsung.",
                color = LocalFg.current.copy(alpha = 0.7f),
                fontSize = 16.sp,
            )
        }
        infos.forEach { (id, info) ->
            key(id) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = info.loadLabel(pm).toString(),
                            color = LocalFg.current.copy(alpha = 0.7f),
                            fontSize = 15.sp,
                            modifier = Modifier.weight(1f),
                        )
                        ChipButton(text = "Entfernen", onClick = { remove(id) })
                    }
                    AndroidView(
                        factory = { ctx -> host.createView(ctx, id, info) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(maxOf(info.minHeight, 120).dp),
                    )
                }
            }
        }
    }

    if (picking) {
        val providers = remember {
            manager.installedProviders.sortedBy { it.loadLabel(pm).toString().lowercase() }
        }
        AlertDialog(
            onDismissRequest = { picking = false },
            title = { Text(text = "Widget wählen") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                    items(providers, key = { it.provider.flattenToString() }) { info ->
                        Text(
                            text = info.loadLabel(pm).toString(),
                            color = Color.White,
                            fontSize = 17.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    picking = false
                                    startBind(info)
                                }
                                .padding(vertical = 12.dp),
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { picking = false }) {
                    Text(text = "Schließen")
                }
            },
        )
    }
}

/** Einstellungen eines Widgets öffnen, bevor es auf die Seite kommt */
private fun configIntent(id: Int, component: ComponentName): Intent =
    Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE)
        .setComponent(component)
        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
