package com.example.tablethome

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp

/*
 * Moderne, animierte Symbole für die Infos rechts.
 * Alles selbst gezeichnet, keine fremden Bilder.
 */

private val White = Color.White
private val Dim = Color(0x40FFFFFF)
private val SunYellow = Color(0xFFFFD25A)
private val BoltYellow = Color(0xFFFFE066)

/** Läuft endlos von 0 bis 1 (für das Wetter). */
@Composable
private fun loop(durationMs: Int): androidx.compose.runtime.State<Float> {
    val transition = rememberInfiniteTransition(label = "loop")
    return transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMs, easing = LinearEasing), RepeatMode.Restart),
        label = "t",
    )
}

/** Bogen, der von etwas kleiner auf volle Größe wächst, während er erscheint. */
private fun DrawScope.growingArc(
    center: Offset,
    radius: Float,
    progress: Float,
    startAngle: Float,
    color: Color,
    stroke: Float,
) {
    val r = radius * (0.75f + 0.25f * progress)
    drawArc(
        color = color,
        startAngle = startAngle,
        sweepAngle = 90f,
        useCenter = false,
        topLeft = Offset(center.x - r, center.y - r),
        size = Size(r * 2, r * 2),
        style = Stroke(width = stroke, cap = StrokeCap.Round),
    )
}

/** Ton/Bluetooth: Punkt und drei Bögen nach rechts, ganz in Weiß, ohne Bewegung. Blass, wenn nichts verbunden ist. */
@Composable
fun SoundIcon(connected: Boolean) {
    val color = if (connected) White else Dim
    Canvas(Modifier.size(28.dp)) {
        val w = size.width
        val stroke = w * 0.095f
        val c = Offset(w * 0.16f, size.height / 2f)
        drawCircle(color, radius = stroke * 0.85f, center = c)
        for (i in 1..3) growingArc(c, w * 0.24f * i, 1f, -45f, color, stroke)
    }
}

/** WLAN: Punkt unten und drei Bögen. So viele Bögen sind weiß, wie die Signalstärke hergibt, der Rest bleibt blass. */
@Composable
fun WifiIcon(level: Int) {
    Canvas(Modifier.size(30.dp)) {
        val w = size.width
        val h = size.height
        val stroke = w * 0.09f
        val c = Offset(w / 2f, h * 0.86f)
        drawCircle(if (level > 0) White else Dim, radius = stroke * 0.9f, center = c)
        for (i in 1..3) growingArc(c, h * 0.24f * i, 1f, -135f, if (i <= level) White else Dim, stroke)
    }
}

/** Kalender-Symbol mit Tageszahl */
@Composable
fun CalendarIcon(day: Int) {
    androidx.compose.foundation.layout.Column(
        modifier = Modifier
            .size(30.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(6.dp))
            .background(White),
        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
    ) {
        androidx.compose.foundation.layout.Box(
            Modifier
                .fillMaxWidth()
                .height(8.dp)
                .background(Color(0xFFFF3B30))
        )
        androidx.compose.material3.Text(
            text = day.toString(),
            color = Color(0xFF1C1C1E),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 18.sp,
        )
    }
}

/** Wetter passend zum Open-Meteo-Code, leicht animiert. */
@Composable
fun WeatherIcon(code: Int) {
    // Animationen nur dort, wo sie gebraucht werden, und erst beim Zeichnen gelesen:
    // so wird nur das kleine Symbol neu gezeichnet, nicht der Bildschirm neu aufgebaut
    val hasSun = code in 0..2
    val hasMotion = code == 45 || code == 48 || code in 51..67 || code in 71..86 || code in 95..99
    val slowState = if (hasSun) loop(12_000) else null
    val fastState = if (hasMotion) loop(1200) else null
    Canvas(Modifier.size(32.dp)) {
        val t = slowState?.value ?: 0f
        val fast = fastState?.value ?: 0f
        when (code) {
            0 -> sun(Offset(size.width / 2, size.height / 2), size.width * 0.2f, t)
            1, 2 -> {
                sun(Offset(size.width * 0.38f, size.height * 0.36f), size.width * 0.15f, t)
                cloud(Offset(size.width * 0.58f, size.height * 0.64f), size.width * 0.8f)
            }
            45, 48 -> fog(fast)
            in 51..67, in 80..82 -> {
                cloud(Offset(size.width / 2, size.height * 0.4f), size.width)
                rain(fast)
            }
            in 71..77, 85, 86 -> {
                cloud(Offset(size.width / 2, size.height * 0.4f), size.width)
                snow(fast)
            }
            in 95..99 -> {
                cloud(Offset(size.width / 2, size.height * 0.4f), size.width)
                bolt(fast)
            }
            else -> cloud(Offset(size.width / 2, size.height / 2), size.width)
        }
    }
}

private fun DrawScope.sun(c: Offset, r: Float, t: Float) {
    drawCircle(SunYellow, radius = r, center = c)
    rotate(degrees = t * 360f, pivot = c) {
        for (k in 0 until 8) {
            rotate(degrees = k * 45f, pivot = c) {
                drawLine(
                    color = SunYellow,
                    start = Offset(c.x, c.y - r * 1.45f),
                    end = Offset(c.x, c.y - r * 1.95f),
                    strokeWidth = r * 0.28f,
                    cap = StrokeCap.Round,
                )
            }
        }
    }
}

/** Wolke aus drei Kreisen und einem abgerundeten Boden. */
private fun DrawScope.cloud(c: Offset, w: Float) {
    val u = w / 10f
    drawCircle(White, radius = u * 2.0f, center = Offset(c.x - u * 1.9f, c.y + u * 0.3f))
    drawCircle(White, radius = u * 2.7f, center = Offset(c.x + u * 0.2f, c.y - u * 0.6f))
    drawCircle(White, radius = u * 1.9f, center = Offset(c.x + u * 2.4f, c.y + u * 0.4f))
    drawRoundRect(
        color = White,
        topLeft = Offset(c.x - u * 3.9f, c.y + u * 0.3f),
        size = Size(u * 8.2f, u * 2.0f),
        cornerRadius = CornerRadius(u, u),
    )
}

private fun DrawScope.rain(t: Float) {
    val u = size.width / 10f
    for (k in 0 until 3) {
        val x = size.width * (0.3f + 0.2f * k)
        val phase = (t + k * 0.33f) % 1f
        val y = size.height * 0.68f + phase * u * 2.6f
        drawLine(
            color = Color(0xFF9ED0FF).copy(alpha = 1f - phase),
            start = Offset(x, y),
            end = Offset(x - u * 0.4f, y + u * 1.2f),
            strokeWidth = u * 0.6f,
            cap = StrokeCap.Round,
        )
    }
}

private fun DrawScope.snow(t: Float) {
    val u = size.width / 10f
    for (k in 0 until 3) {
        val x = size.width * (0.3f + 0.2f * k)
        val phase = (t + k * 0.33f) % 1f
        drawCircle(
            color = White.copy(alpha = 1f - phase),
            radius = u * 0.55f,
            center = Offset(x, size.height * 0.7f + phase * u * 2.6f),
        )
    }
}

private fun DrawScope.bolt(t: Float) {
    val flash = if (t < 0.15f || t in 0.25f..0.32f) 1f else 0.55f
    val p = Path().apply {
        moveTo(size.width * 0.55f, size.height * 0.6f)
        lineTo(size.width * 0.4f, size.height * 0.82f)
        lineTo(size.width * 0.52f, size.height * 0.82f)
        lineTo(size.width * 0.44f, size.height * 1.0f)
        lineTo(size.width * 0.66f, size.height * 0.74f)
        lineTo(size.width * 0.54f, size.height * 0.74f)
        close()
    }
    drawPath(p, BoltYellow.copy(alpha = flash))
}

private fun DrawScope.fog(t: Float) {
    val u = size.width / 10f
    for (k in 0 until 3) {
        val shift = kotlin.math.sin((t + k * 0.3f) * 2 * Math.PI).toFloat() * u * 0.8f
        val y = size.height * (0.3f + 0.2f * k)
        drawLine(
            color = White.copy(alpha = 0.9f - 0.2f * k),
            start = Offset(size.width * 0.15f + shift, y),
            end = Offset(size.width * 0.85f + shift, y),
            strokeWidth = u * 0.7f,
            cap = StrokeCap.Round,
        )
    }
}
