package com.example.tablethome

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Hellerer Hintergrund: die Schrift ist dunkel, also werden auch die Flächen dunkler getönt */
private fun onLightBackground(fg: Color): Boolean = fg != Color.White

/** Kleine Schaltfläche mit Glas-Hintergrund, z. B. für "Zurück" oder "Entfernen" */
@Composable
fun ChipButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val fg = LocalFg.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (onLightBackground(fg)) Color(0x1F000000) else Color(0x33FFFFFF))
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = fg,
            fontSize = 18.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** Eine App-Kachel in der Startreihe: Name in der Mitte, Antippen startet die App */
@Composable
fun NameTile(name: String, onClick: () -> Unit, modifier: Modifier = Modifier, highlight: Boolean = false) {
    val fg = LocalFg.current
    val tile = when {
        onLightBackground(fg) -> Color(0x1F000000)
        highlight -> Color(0x66FFFFFF)
        else -> Color(0x40000000)
    }
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(92.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(tile)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = name,
            color = fg,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
